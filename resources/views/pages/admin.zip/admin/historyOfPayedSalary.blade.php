@extends("layouts.profile")

@section("title") Выплаченные зарплаты @endsection


@section('content')

  @include('pages.admin.header')

  <div class="dashboard table-responsive">
    <div class="dashboard__amounts" style="border:1px solid #eee; padding:25px; border-radius:7px; margin-top:2px;">
      <h4 class="text-center">Выплаченные зарплаты</h4>
      <div class="dashboard__params mb-5" style="text-align: center">
        <form method="POST" class="form">
          @csrf
          {{--month and year selecting--}}
          <small style='font-size:16px'>Сотрудник:</small>
          <div class="wrap-input100 rs1 validate-input">
            <select class="form-control imprt" name="teacher_id" id="teacher_id" required>
              @foreach ( $teachers as $teacher )
                <option id='searchable' class='checked' @if(isset($teacher_id) and $teacher->id == $teacher_id) selected
                        @endif value={{$teacher->id}}>{{$teacher->name}}</option>
              @endforeach
            </select>
            <span class="focus-input100-1"></span>
            <span class="focus-input100-2"></span>
            <div class="form__submit">
              <button type="submit" class="btn btn-data text-center mt-2">Получить данные
              </button>
              <a href="{{route('admin.analytic.paySalary')}}" class="btn btn-data text-center mt-2">Выплатить зарплату
              </a>
            </div>
        </form>
      </div>

    </div>
    @if ($show)
      <div class="container">
        <div class="accordion table-responsive" id="accordionExample">
          <div class="container-fluid">
            <table class="table table-striped table-hover table-bordered text-center">
              <thead class="table-dark">
              <th>Дата</th>
              <th>Название операции</th>
              <th>Величина</th>
              </thead>
              <tbody>
              <tr>
                <td>БАЛАНС</td>
                <td>-</td>
                <td>{{$sum}}</td>
              </tr>
              @foreach ($information as $sal)
                <tr>
                  <td>{{ date("d.m.Y H:i:s",strtotime($sal["created_at"])) }}</td>
                  <td>
                    @if ($sal["type"] == 1)
                      Оплата за урок от {{\Carbon\Carbon::parse($sal["created_at"])->format("d.m.Y")}} за
                      группу {{$sal["name_group"]}}
                    @elseif ($sal["type"]==2)
                      Оплата зарплаты
                    @else
                      Оплата премии
                    @endif
                  </td>
                  <td id="month_salary">{{ $sal["value"] }}</td>
                </tr>
              @endforeach

              </tbody>
            </table>
          </div>
        </div>
      </div>
  </div>
  @endif
@endsection