@extends("layouts.profile")

@section("title") Добавить пост@endsection

<link rel="stylesheet" href="{{ asset("css/forms.css") }}">



@section('content')
  @include('pages.admin.header')

  <div class="limiter">
    <div class="container-login100 container-fluid h-full">
      <div class="wrap-login100 p-l-15 p-r-55 p-t-25 p-b-50">
        <form class="login100-form validate-form p-t-45 p-l-25" method="POST" enctype="multipart/form-data">
          @csrf
          @method("POST")
          @include('layouts.alerts')
          <span class="login100-form-title p-b-33">
          Добавление поста
        </span>
          <small style='font-size:16px; color:#666'>Название:</small>
          <div class='mt-1 mb-2 wrap-input100 rs1 validate-input'>
            <input class='input100' name='title' required placeholder="Название ...">
            <span class='focus-input100-1'></span>
            <span class='focus-input100-2'></span>
          </div>
          <small style='font-size:16px; color:#666'>Описание: </small>
          <div class='mt-1 mb-2 wrap-input100 rs1 validate-input'>
            <textarea class='input100' name='description' required placeholder="Описание ..." rows="15"></textarea>
            <span class='focus-input100-1'></span>
            <span class='focus-input100-2'></span>
          </div>
          <small style='font-size:16px; color:#666'>Изображение: </small>
          <div class='mt-1 mb-2 wrap-input100 rs1 validate-input'>
            <input type="file" name="file" class="form-control">
          </div>
          <div class='container-login100-form-btn m-t-20'>
            <button class='login100-form-btn'>
              Добавить
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
@endsection
