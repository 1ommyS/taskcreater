@extends("layouts.profile")

@section("title") Ученики @endsection
@section('content')

  @include('pages.admin.header')
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
          integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
          crossorigin="anonymous"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.23/datatables.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.23/datatables.min.css" />

  <script>
    $(document).ready(function () {
      $('#myTable').DataTable();
    });
  </script>
  <div class="wrapper m-5 table-responsive">
    @include("layouts.alerts")

    <div class="button mb-3">
      <a class='btn btn-sm btn-orange' style="color:white;" href='/profile/post'>Добавить пост</a>
    </div>
    <table id="myTable" data-page-length='50' class="table table-hover table-striped border table-bordered table-sm">
      <thead class="table-dark">
      <tr>
        <th data-id="1">Номер <i class="fas fa-sort"></i></th>
        <th scope="col" data-id="2">Название <i class="fas fa-sort"></i></th>
        <th scope="col" data-id="3">Описание <i class="fas fa-sort"></i></th>
        <th scope="col" data-id="4">Картинка <i class="fas fa-sort"></i></th>
        <th scope="col" data-id="5">Редактировать <i class="fas fa-sort"></i></th>
        <th scope="col" data-id="6">Удалить <i class="fas fa-sort"></i></th>
      </tr>
      </thead>
      <tbody>
      @foreach($posts as $post)
        <tr>
          <td>{{ $post->id }}</td>
          <td>{{ $post->title }}</td>
          <td>{!! $post->description !!}</td>
          <td><img src="{{ asset("public/file/blog/images/{$post->pathToImage}") }}" class="card-img-top" alt="..."
                   style="width:25% !important; height: 25% !important;">
          </td>
          <td>
            <a class='btn btn-sm btn-orange' style="color: #fff"
               href='/profile/post/edit/{{$post->id}}'>Редактировать</a>
          </td>
          <td>
            <a class='btn btn-sm btn-orange'
               style="color: #fff;    background: linear-gradient(to bottom, #ff3245, #e10909) !important;"
               href='/profile/post/delete/{{$post->id}}'>Удалить</a>
          </td>
        </tr>
      @endforeach
      </tbody>
    </table>
  </div>
@endsection