@extends("layouts.profile")

@section("title") Итоговая аналитика @endsection

@section('content')
  @include('pages.admin.header')

  <div class="dashboard">
    <div class="dashboard__amounts" style="border:1px solid #eee; padding:25px; border-radius:7px; margin-top:2px;">
      <h4 class="text-center">Сводная таблица</h4>
      <div class="dashboard__params mb-5" style="text-align: center">
        <form method="POST" class="form">
          @csrf
          <div class="form-control">
            <label for="start">С какого дня: </label>
            <input type="date" id="start" value="{{ isset($start) ? $start : date("Y-m-d") }}" name="day_start"
                   style="width:150px">
          </div>
          <br>
          <div class="form-control">
            <label for="finish">По какой день: </label>
            <input type="date" id="finish" value="{{ isset($finish) ? $finish : date("Y-m-d") }}" name="day_finish"
                   style="width:150px">
          </div>
          <div class="form__submit">
            <button type="submit" class="btn btn-data text-center mt-2">Получить данные</button>
            <a href="/profile/setpercent" class="btn btn-data text-center mt-2">Установить банковский процент
            </a>
          </div>
        </form>
      </div>
      @if(!isset($show))
        <div class="accordion" id="accordionExample">
          <div class="container-fluid table-responsive">
            @if (!empty($information))
              @foreach($information as $index => $info)
                <div class="card mt-3">
                  <div class="card-header" id="acc{{ $index }}">

                    <button
                      class="btn btn-link"
                      type="button"
                      data-mdb-toggle="collapse"
                      data-mdb-target="#accounting{{ $index }}"
                      aria-expanded="false"
                      aria-controls="collapseExample"
                    >
                      {{ $index + 1 }} неделя ( {{ implode(".",array_reverse(explode("-",$weeks[$index]['start'])))}}
                                       - {{ implode(".",array_reverse(explode("-",$weeks[$index]['end']))) }})
                    </button>
                  </div>
                  <div id="accounting{{ $index }}" class="collapse" aria-labelledby="{{ $index }}"
                       data-parent="#accordionExample">
                    <div class="card-body table-responsive">
                      <table class="table table-striped table-bordered text-center">
                        <thead class="table-dark">
                        <th>Выручка</th>
                        <th>Банковский процент</th>
                        <th>Выручка с учетом банковского процента</th>
                        <th>Оплата ЗП</th>
                        <th>Оплата премий</th>
                        <th>Оплата ЗП с учетом премий</th>
                        <th>Дополнительные затраты</th>
                        <th>Прибыль</th>
                        </thead>
                        <tbody>
                        <tr>
                          <td>{{ $info['revenue'] }}</td>
                          <td id="accHM{{ $index + 1 }}">{{ $info['percent'] }}</td>
                          <td id="accVD{{ $index + 1 }}">{{ $info['revenue_with_percent'] }}</td>
                          <td id="accAL{{ $index + 1 }}">{{ $info['wages'] }}</td>
                          <td id="accRV{{ $index + 1 }}">{{ $info['premiums'] }}</td>
                          <td id="accPrem{{ $index + 1 }}">{{ $info['wages_with_premiums'] }}</td>
                          <td id="accFinals{{ $index + 1 }}">{{ $info['other_payments'] }}</td>
                          <td id="accFinals{{ $index + 1 }}">{{ $info['income'] }}</td>
                        </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              @endforeach
              <div class="card mt-3">
                <div class="card-header" id="acc{{ $index+132 }}">
                  <button
                    class="btn btn-link"
                    type="button"
                    data-mdb-toggle="collapse"
                    data-mdb-target="#accounting{{ $index+132 }}"
                    aria-expanded="false"
                    aria-controls="collapseExample"
                  >
                    Период ( {{ implode(".",array_reverse(explode("-",$weeks[0]['start'])))}}
                    - {{ implode(".",array_reverse(explode("-",$weeks[count($weeks)-1]['end']))) }})
                  </button>

                </div>
                <div id="accounting{{ $index+132 }}" class="collapse" aria-labelledby="{{ $index+132 }}">
                  <div class="card-body table-responsive">
                    <table class="table border table-striped table-bordered table-hover text-center">
                      <thead class="table-dark">
                      <th>Выручка</th>
                      <th>Банковский процент</th>
                      <th>Выручка с учетом банковского процента</th>
                      <th>Оплата ЗП</th>
                      <th>Оплата премий</th>
                      <th>Оплата ЗП с учетом премий</th>
                      <th>Дополнительные затраты</th>
                      <th>Прибыль</th>
                      </thead>
                      <tbody>
                      <tr>
                        <td>{{ $period['revenue'] }}</td>
                        <td id="accHM{{ $index + 1 }}">{{ $period['percent'] }}</td>
                        <td id="accVD{{ $index + 1 }}">{{ $period['revenue_with_percent'] }}</td>
                        <td id="accAL{{ $index + 1 }}">{{ $period['wages'] }}</td>
                        <td id="accRV{{ $index + 1 }}">{{ $period['premiums'] }}</td>
                        <td id="accPrem{{ $index + 1 }}">{{ $period['wages_with_premiums'] }}</td>
                        <td id="accFinals{{ $index + 1 }}">{{ $period['other_payments'] }}</td>
                        <td id="accFinals{{ $index + 1 }}">{{ $period['income'] }}</td>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            @endif
          </div>
        </div>
      @endisset
    </div>
  </div>
@endsection