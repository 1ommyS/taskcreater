@extends("layouts.profile")

@section("title") Выплатить зарплату@endsection

<link rel="stylesheet" href="{{ asset("css/forms.css") }}">



@section('content')


  @include('pages.admin.header')

  <div class="limiter table-reponsive h-100">
    <div class="container-login100 container-fluid h-100">
      <div class="wrap-login100 p-l-15 p-r-55 p-t-25 p-b-50">
        <a href="/profile/auxil" class="btn-sm btn-orange"
           style="color:white;border:1px solid #eee;padding-left:20px;padding-right:20px"> <i class="fa fa-arrow-left" aria-hidden="true"></i>
          Назад</a>
        <form class="login100-form validate-form p-t-45 p-l-25" method="POST">
          @csrf
          @include('layouts.alerts')

          <span class="login100-form-title p-b-33">
          Оплата зарплаты
        </span>
          <small style='font-size:16px'>Сотрудник:</small>
          <div class="wrap-input100 rs1 validate-input">
            <select class="form-control imprt" name="teacher_id" id="teacher_id" required>
              @foreach ( $teachers as $teacher )
                <option id='searchable' class='checked' value={{$teacher->id}}>{{$teacher->name}}</option>
              @endforeach
            </select>
            <span class="focus-input100-1"></span>
            <span class="focus-input100-2"></span>
          <small style='font-size:16px; color:#666'>Сумма: </small>
          <div class='mt-1 mb-2 wrap-input100 rs1 validate-input'>
            <input class='input100' name='value' type="number" placeholder="1000">
            <span class='focus-input100-1'></span>
            <span class='focus-input100-2'></span>
          </div>
            <small style='font-size:16px; color:#666'>Дата выплаты: </small>
          <div class='mt-1 mb-2 wrap-input100 rs1 validate-input'>
            <input class='input100' name='date' type="date">
            <span class='focus-input100-1'></span>
            <span class='focus-input100-2'></span>
          </div>

          <div class='container-login100-form-btn m-t-20'>
            <button class='login100-form-btn'>
              Добавить
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
@endsection