<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <span class="navbar-brand ">С возвращением, <br> {{ Auth::user() ->login}}</span>
  <button
    class="navbar-toggler"
    type="button"
    data-mdb-toggle="collapse"
    data-mdb-target="#navbarSupportedContent"
    aria-controls="navbarSupportedContent"
    aria-expanded="false"
    aria-label="Toggle navigation"
  >
    <i class="fas fa-bars"></i>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <div class="navbar-nav">

      <li class="nav-item dropdown">
        <a
          class="nav-link  dropdown-toggle nav-item"
          href="#"
          id="analytic"
          role="button"
          data-mdb-toggle="dropdown"
          aria-expanded="false"
        >
          Аналитика
        </a>
        <!-- Dropdown menu -->
        <ul class="dropdown-menu" aria-labelledby="analytic">
          <li>
            <a href="{{route("admin.analytic.auxilPayments")}}" class="dropdown-item">Дополнительные расходы
                                                                                      (Период)</a>
          </li>
          <li>
            <a href="{{route("admin.analytic.auxilPaymentsInMonth")}}" class="dropdown-item">Дополнительные расходы
                                                                                             (Месяц)</a>
          </li>
          <li>
            <a href="/profile" class="dropdown-item">Аналитика (преподаватели)</a>
          </li>
          <li>
            <a href="{{route("admin.analytic.month")}}" class="dropdown-item">Аналитика (месяц)</a>
          </li>
          <li>
            <a href="{{route("admin.analytic.payedSalaries")}}" class="dropdown-item">Зарплаты</a>
          </li>

          <li>
            <a href="{{route("admin.analytic.analyticInPeriod")}}" class="dropdown-item">Аналитика (период)</a>
          </li>
        </ul>
      </li>
      <li class="nav-item dropdown">
        <a
          class="nav-link dropdown-toggle nav-item"
          href="#"
          id="infrastructure"
          role="button"
          data-mdb-toggle="dropdown"
          aria-expanded="false"
        >
          Структура организации
        </a>
        <!-- Dropdown menu -->
        <ul class="dropdown-menu" aria-labelledby="infrastructure">
          <li>
            <a href="{{route("admin.struct.teachers")}}" class="dropdown-item">Учителя</a>
          </li>
          <li>
            <a href="{{route("admin.struct.students")}}" class="dropdown-item">Ученики</a>
          </li>
          <li>
            <a href="{{route("admin.struct.birthdays")}}" class="dropdown-item">Дни рождения</a>
          </li>
          <li>
            <a href="{{route("admin.struct.groups")}}" class="dropdown-item">Группы</a>
          </li>
        </ul>
      </li>
      <li class="nav-item dropdown">
        <a
          class="nav-link dropdown-toggle nav-item"
          href="#"
          id="site"
          role="button"
          data-mdb-toggle="dropdown"
          aria-expanded="false"
        >
          Сайт
        </a>
        <!-- Dropdown menu -->
        <ul class="dropdown-menu" aria-labelledby="site">

          <li>
            <a href="/profile/posts" class="dropdown-item">Блог</a>
          </li>
        </ul>
      </li>

      <li class="nav-item dropdown">
        <a
          class="nav-link dropdown-toggle nav-item"
          href="#"
          id="others"
          role="button"
          data-mdb-toggle="dropdown"
          aria-expanded="false"
        >
          Дополнительно
        </a>
        <!-- Dropdown menu -->
        <ul class="dropdown-menu" aria-labelledby="others">
          <li>
            <a href="{{route("admin.instruments.sending")}}" class="dropdown-item">Рассылка</a>
          </li>
          <li>
            <a href="/profile/settings" class="dropdown-item">Персональные данные</a>
          </li>

          <li>
            <a href="{{route("admin.instruments.logs")}}" class="dropdown-item ">Логи</a>
          </li>
          <li>
            <a href="/panel" class="dropdown-item ">Админ панель</a>
          </li>
        </ul>
      </li>
      <a href="/logout" class="nav-item nav-link" tabindex="-1">Выйти из аккаунта</a>
    </div>
  </div>
</nav>
